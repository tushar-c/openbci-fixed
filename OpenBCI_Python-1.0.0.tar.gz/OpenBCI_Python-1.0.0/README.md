# OpenBCI Python

This version of OpenBCI Python fixes issues regarding a particular file called 'plugin_interface.py' in the original version.

Link to the original project -> https://github.com/OpenBCI/OpenBCI_Python